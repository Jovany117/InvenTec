<?php
require_once 'conexion.php';
// Obtener registros de la bitácora de eventos
$sql = "SELECT * FROM logs ORDER BY timestamp DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/admin.css">
    <title>Registro de Autenticación</title>
</head>
<body>
    <div class="container">
        <a href="index.html">Regresar</a>
        <h2>Registro de Autenticación</h2>
        <table>
            <tr>
                <th>Fecha y Hora</th>
                <th>Usuario</th>
                <th>Tipo de Evento</th>
                <th>Detalles</th>
            </tr>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['timestamp'] . "</td>";
                    echo "<td>" . $row['username'] . "</td>";
                    echo "<td>" . $row['event_type'] . "</td>";
                    echo "<td>" . $row['details'] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No hay registros de autenticación.</td></tr>";
            }
            ?>
        </table>
    </div>
</body>
</html>
