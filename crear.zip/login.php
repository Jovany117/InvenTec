<?php
session_start();

require_once 'conexion.php';
require_once 'log.php';

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * FROM usuarios WHERE username='$username'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $hashedPassword = $row['hashed_password'];

    if (password_verify($password, $hashedPassword)) {
        $_SESSION['username'] = $username;
        logEvent($username, "Inicio de sesión exitoso", "El usuario $username inició sesión correctamente.");
        header("Location: bienvenida.php"); 
        exit(); 
    } else {
        logEvent($username, "Intento de inicio de sesión fallido", "Intento fallido de iniciar sesión para el usuario: $username");
        echo "<script>alert('Nombre de usuario o contraseña incorrectos');</script>";
        echo "<script>window.location.href = 'index.html';</script>";
        exit(); 
    }
} else {
    logEvent($username, "Intento de inicio de sesión fallido", "Intento fallido de iniciar sesión para el usuario: $username");
    echo "<script>alert('Nombre de usuario o contraseña incorrectos'); window.location.href = 'index.html';</script>";
}
?>
